# placeholder perspective-service code
