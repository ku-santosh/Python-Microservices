# Placeholder db_service_pb2.py
# NOTE: This is a lightweight placeholder to allow static inspection and imports.
# For production and proper gRPC functionality you MUST regenerate these files using:
# python -m grpc_tools.protoc -I./proto --python_out=./proto --grpc_python_out=./proto proto/db_service.proto

from dataclasses import dataclass
from typing import List

@dataclass
class Empty:
    pass

@dataclass
class Pong:
    message: str = ''

@dataclass
class CreateUserRequest:
    username: str = ''
    password_hash: str = ''

@dataclass
class CreateUserResponse:
    id: int = 0
    error: str = ''

@dataclass
class GetUserRequest:
    username: str = ''

@dataclass
class GetUserResponse:
    id: int = 0
    username: str = ''
    password_hash: str = ''
    error: str = ''

@dataclass
class CreateProductRequest:
    name: str = ''
    price: float = 0.0

@dataclass
class CreateProductResponse:
    id: int = 0
    error: str = ''

@dataclass
class Product:
    id: int = 0
    name: str = ''
    price: float = 0.0

@dataclass
class ListProductsResponse:
    products: List[Product] = None

@dataclass
class CreateOrderRequest:
    user_id: int = 0
    product_id: int = 0
    quantity: int = 0

@dataclass
class CreateOrderResponse:
    id: int = 0
    error: str = ''

@dataclass
class ListOrdersRequest:
    user_id: int = 0

@dataclass
class Order:
    id: int = 0
    user_id: int = 0
    product_id: int = 0
    quantity: int = 0
    status: str = ''

@dataclass
class ListOrdersResponse:
    orders: List[Order] = None
