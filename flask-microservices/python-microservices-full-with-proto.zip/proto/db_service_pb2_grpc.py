# Placeholder db_service_pb2_grpc.py
# NOTE: This is a placeholder. Regenerate with grpc_tools.protoc for real gRPC functionality.
import grpc

class DBServiceServicer:
    pass

class DBServiceStub:
    def __init__(self, channel):
        # channel is expected to be a grpc.Channel in real use
        self._channel = channel
        raise RuntimeError("Placeholder DBServiceStub: pb2_grpc file is a stub. Generate real stubs with grpc_tools.protoc.")
